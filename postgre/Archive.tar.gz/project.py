from interface import QueryOptimizerApp
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    app = QueryOptimizerApp(root)
    root.mainloop()
